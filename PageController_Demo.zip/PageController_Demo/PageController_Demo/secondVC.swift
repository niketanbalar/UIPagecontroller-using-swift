//
//  secondVC.swift
//  PageController_Demo
//
//  Created by Niketan on 30/07/19.
//  Copyright © 2019 Niketan. All rights reserved.
//

import UIKit

class secondVC: UIViewController {

    var pageIndex: Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
