//
//  sliderCollectionViewCell.swift
//  PageController_Demo
//
//  Created by Niketan on 30/07/19.
//  Copyright © 2019 Niketan. All rights reserved.
//

import UIKit

class sliderCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var designView: UIView!
    
    @IBOutlet weak var nameLab: UILabel!
    
}
