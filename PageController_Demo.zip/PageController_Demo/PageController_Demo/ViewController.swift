//
//  ViewController.swift
//  PageController_Demo
//
//  Created by Niketan on 30/07/19.
//  Copyright © 2019 Niketan. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UIPageViewControllerDataSource, UIPageViewControllerDelegate , UICollectionViewDelegate, UICollectionViewDataSource ,UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var pageViewController: UIPageViewController?
    var selectedIndex : Int = 0
    var data = [String]()

    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.pageControllViewDesign()
        
        self.data = ["name 1","name 2","name 3","name 4","name 5"]
    }
    
    // MARK: - Func
    
    func pageControllViewDesign() {
        pageViewController = (storyboard?.instantiateViewController(withIdentifier: "PageVC") as! UIPageViewController)
        pageViewController?.dataSource = self
        pageViewController?.delegate = self
        
        let startingViewController: UIViewController? = viewController(at: 0)
        let viewControllers = [startingViewController]
        pageViewController?.setViewControllers(viewControllers as? [UIViewController], direction: .forward, animated: false) { _ in }
        pageViewController?.view.frame = CGRect(x: 0, y: 100, width: view.frame.size.width, height: view.frame.size.height - 100)
        addChild(pageViewController!)
        view.addSubview((pageViewController?.view)!)
        pageViewController?.didMove(toParent: self)
    }
    
    //MARK:- collectionview Delegate
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! sliderCollectionViewCell
        cell.designView.backgroundColor = UIColor.lightGray
        cell.nameLab.text = data[indexPath.row]
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.row
        
        let startingViewController: UIViewController? = viewController(at: selectedIndex)
        let viewControllers = [startingViewController]
        pageViewController?.setViewControllers(viewControllers as? [UIViewController], direction: .forward, animated: false) { _ in }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if (UIDevice.current.userInterfaceIdiom == .pad){
            print("iPad")
            let w = collectionView.frame.size.width - 50
            let h = collectionView.frame.size.height - 20
            return CGSize(width: ( w / 4 ) , height: ( h ))
        }
        else{
            print("iPhone")
            let w = collectionView.frame.size.width - 40
            let h = collectionView.frame.size.height - 20
            return CGSize(width: ( w / 3 ) , height: ( h ))
        }
    }
    
    
    func scrollCollectionView(selectIndex:Int){
        DispatchQueue.main.async {
            let slide = self.view.frame.size.width * CGFloat(selectIndex)
            self.collectionView.setContentOffset(CGPoint(x: slide , y: 0), animated: false)
        }
    }

    
    // MARK: - Page View Datasource Methods
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        var index: Int = 0
        if (viewController is firstVC) {
            return nil
        }
        else if (viewController is secondVC) {
            index = 1
        }
        else if (viewController is thirdVC) {
            index = 2
        }
        
        index -= 1
        
        return self.viewController(at: index)
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        var index: Int = 0
        if (viewController is firstVC) {
            index = 0
        }
        else if (viewController is secondVC) {
            index = 1
        }
        else if (viewController is thirdVC) {
            return nil
        }
        
        index += 1
        
        return self.viewController(at: index)
    }
    
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        
        if !completed {
            return
        }
        let view: UIViewController? = pageViewController.viewControllers?[0]
        if (view is firstVC) {
            let index: Int? = (view as? firstVC)?.pageIndex
            self.scrollCollectionView(selectIndex: index!)
            self.collectionView.reloadData()
        }
        else if (view is secondVC) {
            let index: Int? = (view as? secondVC)?.pageIndex
            self.scrollCollectionView(selectIndex: index!)
            self.collectionView.reloadData()
        }
        else if (view is thirdVC) {
            let index: Int? = (view as? thirdVC)?.pageIndex
            self.scrollCollectionView(selectIndex: index!)
            self.collectionView.reloadData()
        }
    }
    
    
    func viewController(at index: Int) -> UIViewController?
    {
            if index == 0 {
                let pageContentViewController = storyboard?.instantiateViewController(withIdentifier: "firstVC") as? firstVC
                pageContentViewController?.pageIndex = index
                return pageContentViewController!
            }
            else if index == 1 {
                let pageContentViewController = storyboard?.instantiateViewController(withIdentifier: "secondVC") as? secondVC
                pageContentViewController?.pageIndex = index
                return pageContentViewController!
            }
            else {
                let pageContentViewController = storyboard?.instantiateViewController(withIdentifier: "thirdVC") as? thirdVC
                pageContentViewController?.pageIndex = index
                return pageContentViewController!
            }
     }

}

